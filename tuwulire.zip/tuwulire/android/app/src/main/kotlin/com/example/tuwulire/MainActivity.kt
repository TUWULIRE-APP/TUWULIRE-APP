package com.example.tuwulire

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
