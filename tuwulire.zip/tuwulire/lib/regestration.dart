import 'package:flutter/material.dart';

class regestration extends StatefulWidget {
  const regestration({Key? key}) : super(key: key);

  @override
  State<regestration> createState() => _regestrationState();
}

class _regestrationState extends State<regestration> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
       home: Container(
         color: Colors.cyan,
       ),
    );


  }
}
